# VerdeSip Website Demo

This is a responsive front-end website concept for VerdeSip, prepared for client presentation.

## Included
- Homepage and hero section
- Product color collection: Mint Green, Sky Blue, Lavender, Black
- Product feature highlights
- Brand story section
- Launch offer section (VERDE15)
- FAQ section
- Responsive desktop/mobile layout

## Important
This is a design demo only. Cart, checkout, payments, and order processing are not connected.
The `VERDE15` offer and product claims should be confirmed by the client before the site is published publicly.
No custom domain or live URL is included in this package.

## Publish with GitHub Pages
1. Create a public GitHub repository.
2. Upload `index.html` to the repository root.
3. Open Settings → Pages.
4. Choose “Deploy from a branch”, select `main` and `/(root)`, then Save.
5. Wait for GitHub Pages to publish the site and use the URL it provides.
